using PFactoryMethod.CreadorComparables;
using PFactoryMethod.CreadorAlumnos;
using Clases.Alumnos;

namespace Run.Prueba
{
    public class Pruebas
    {
        public static void Run()
        {
            

        }
    }
}