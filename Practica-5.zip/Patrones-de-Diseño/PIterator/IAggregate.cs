namespace PIterator
{
    public interface IAggregate
    {
        IIterator CrearIterador();
    }
}