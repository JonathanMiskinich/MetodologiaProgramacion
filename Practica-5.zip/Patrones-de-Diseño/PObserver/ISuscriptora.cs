namespace PObserver.Suscriptora
{
    public interface ISuscriptora
    {
        public void Update(bool b);
    }
}