namespace PCommand
{
    public interface OrdenEnAula1
    {
        void Ejecutar();
    }
}