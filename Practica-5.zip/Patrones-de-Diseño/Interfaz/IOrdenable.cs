namespace PCommand
{
    public interface Ordenable
    {
        void SetOrdenInicio(OrdenEnAula1 orden);
        void SetOrdenLlegaAlumno(OrdenEnAula2 orden);
        void SetOrdenAulaLlena(OrdenEnAula1 orden);

    }
}