using Interfaces_Practica1;

namespace PCommand
{
    public interface OrdenEnAula2
    {
        void Ejecutar(Comparable c);
    }
}